Use an internet browser to navigate to http://lcd-menu-bulder.cohesivecomputing.co.uk/

Copy and paste contents of a sample menu xml file in to the top text input box. Build the menu code, then copy and paste output in to MenuData.h file, overwriting all existing content.

Use Arduino IDE to build and upload sketch to your Arduino.